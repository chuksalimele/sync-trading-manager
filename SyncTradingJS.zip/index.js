
const electron = nodeRequire('electron') 
const ipc = electron.ipcRenderer; 

var cursorIndex = 0;

var paired_accounts = [];//map

var unpaired_accounts = [];

var logs = [];

var MAX_LOG_RECORDS = 200;

$(document).ready(function () {


    $("#btn-main").on('click', function () {
        hideCenterContents();
        $('#btn-main').addClass('active');
        $('#center-content-main').fadeIn();
    })


    $("#btn-output").on('click', function () {
        hideCenterContents();
        $('#btn-output').addClass('active');
        $('#center-content-output').fadeIn();
        displayLog();
    })

    $("#btn-settings").on('click', function () {
        hideCenterContents();
        $('#btn-settings').addClass('active');
        $('#center-content-settings').fadeIn();
    })

    function hideCenterContents() {
        $("#center-content-main").hide();
        $("#center-content-output").hide();
        $("#center-content-settings").hide();

        $('#btn-main').removeClass('active');
        $('#btn-output').removeClass('active');
        $('#btn-settings').removeClass('active');
    }

    ipc.send('start-sync', true);

    ipc.on('sync-running', function (event, arg) {

        console.log('sync-running', arg);

        addSuccessLog("Sync serivce running...");
        
    });

    ipc.on('sync-restart', function (event, arg) {

        console.log('sync-restart', arg);

        addSuccessLog("Sync serivce restart...");
        
    });

    ipc.on('sync-close', function (event, arg) {

        console.log('sync-close', arg);

        addInfoLog("Sync serivce closed!");

    });

    ipc.on('intro', function (event, arg) {

        console.log('intro', arg);
        
        if (setAccount(arg)) {
            refreshActionList(arg);
        }
    });

    ipc.on('paired', function (event, arg) {

        console.log('paired', arg);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('account-disconnect', function (event, arg) {

        console.log('account-disconnect', arg);

        addInfoLog(`[${arg.broker}, ${arg.account_number}]  is disconnected!`);

        if (removeAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('order', function (event, arg) {

        console.log('order', arg);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('sending-sync-copy', function (event, arg) {

        console.log('sending-sync-copy', arg);

        addInfoLog(`[${arg.account.broker}, ${arg.account.account_number}]  sending sync copy to [${arg.account.peer.broker}, ${arg.account.peer.account_number}]`);

        if (setAccount(arg.account)) {
            refreshPairedTable();
        }
    });

    ipc.on('sync-copy-success', function (event, arg) {

        console.log('sync-copy-success', arg);

        addSuccessLog(`[${arg.account.broker}, ${arg.account.account_number}] sync copy successful.`);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('sync-copy-fail', function (event, arg) {

        console.log('sync-copy-fail', arg);

        addErrorLog(`[${arg.account.broker}, ${arg.account.account_number}] sync copy failed!`);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('sending-sync-close', function (event, arg) {

        console.log('sending-sync-close', arg);

        addInfoLog(`[${arg.account.broker}, ${arg.account.account_number}]  sending sync close to [${arg.account.peer.broker}, ${arg.account.peer.account_number}]`);

        if (setAccount(arg.account)) {
            refreshPairedTable();
        }
    });


    ipc.on('sync-close-success', function (event, arg) {

        console.log('sync-close-success', arg);

        addSuccessLog(`[${arg.account.broker}, ${arg.account.account_number}] sync close successful.`);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('sync-close-fail', function (event, arg) {

        console.log('sync-close-fail', arg);

        addErrorLog(`[${arg.account.broker}, ${arg.account.account_number}] sync close failed!`);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('sending-modify-target', function (event, arg) {

        console.log('sending-modify-target', arg);

        addInfoLog(`[${arg.account.broker}, ${arg.account.account_number}]  sending sync modify target to [${arg.account.peer.broker}, ${arg.account.peer.account_number}]`);

        if (setAccount(arg.account)) {
            refreshPairedTable();
        }
    });

    ipc.on('modify-target-success', function (event, arg) {

        console.log('modify-target-success', arg);

        addSuccessLog(`[${arg.account.broker}, ${arg.account.account_number}] sync modify target successful.`);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('modify-target-fail', function (event, arg) {

        console.log('modify-target-fail', arg);

        addErrorLog(`[${arg.account.broker}, ${arg.account.account_number}] sync modify target failed!`);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('sending-modify-stoploss', function (event, arg) {

        console.log('sending-modify-stoploss', arg);

        addInfoLog(`[${arg.account.broker}, ${arg.account.account_number}]  sending sync modify stoploss to [${arg.account.peer.broker}, ${arg.account.peer.account_number}]`);

        if (setAccount(arg.account)) {
            refreshPairedTable();
        }
    });

    ipc.on('modify-stoploss-success', function (event, arg) {

        console.log('modify-stoploss-success', arg);

        addSuccessLog(`[${arg.account.broker}, ${arg.account.account_number}] sync modify stoploss successful.`);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

    ipc.on('modify-stoploss-fail', function (event, arg) {

        console.log('modify-stoploss-fail', arg);

        addErrorLog(`[${arg.account.broker}, ${arg.account.account_number}] sync modify stoploss failed!`);

        if (setAccount(arg)) {
            refreshPairedTable();
        }
    });

})


function addInfoLog(str_log) {
    addLog(str_log, 'info');
}


function addSuccessLog(str_log) {
    addLog(str_log, 'success');
}


function addErrorLog(str_log) {
    addLog(str_log, 'error');
}

function addLog(str_log, type) {
    

    var logObj = {
        type: type,
        time: new Date(),
        data: str_log
    };

    logs.push(logObj);
    if (logs.length > MAX_LOG_RECORDS) {
        logs.shift();//remove the first element
    }

    document.getElementById('output-count').innerHTML = logs.length;
    
    if ($('#btn-output').hasClass('active')) {
        displayLog();
    }
    
}

function displayLog() {

    var html = '';
    var timezone = '';
    var cell_padding = ' style = "padding-top:3px !important;padding-bottom:3px !important;"';
    
    for (var i = logs.length - 1; i > -1; i--) {
        var objLog = logs[i];
        if (!timezone) {
            //alert((objLog.time + ""));
            timezone = (objLog.time + "").substring(25, 33);
        }
        var date_arr = new Date(objLog.time.getTime() - (objLog.time.getTimezoneOffset() * 60000))
            .toISOString()
            .split("T");
        var date_time = date_arr[0] + ' '+date_arr[1].substring(0, 8);

        var icon = '';
        switch (objLog.type) {
            case 'info': icon = 'info circle icon'; break;
            case 'success': icon = 'check circle green icon'; break;
            case 'error': icon = 'close icon icon red'; break;
        }

        html += `<tr>
          <td class="collapsing" ${cell_padding}><i class="${icon}"></i></td>
          <td ${cell_padding}>${date_time}</td>
          <td ${cell_padding}>${objLog.data}</td>
        </tr>`;

    }

    html = `
        <table class="ui selectable celled single line table">
        <thead>
            <tr>
              <th colspan = "2" ${cell_padding}>Time  ${timezone}</th>
              <th ${cell_padding}>Message</th>
            </tr>
          </thead>
        <tbody>
        ${html}
        </tbody>
        </table>`;

    if (html) {
        document.getElementById('center-content-output').innerHTML = html;
    }

}

function cursorNext() {
    if (cursorIndex < Object.keys(paired_accounts).length - 1) {
        cursorIndex++;
    }
}

function cursorPrev() {
    if (cursorIndex > 0) {
        cursorIndex--;
    }
}

function currentPair() {
    var index = -1;
    for (var n in paired_accounts) {
        index++;
        if (index == cursorIndex) {
            return paired_accounts[n];
        }
    }
}

function showPaired(broker, account_number) {
    //we will use broker and account_number to find since the pair_id is not available at the begining when the accounts are unpaired
    var index = -1;
    for (key in paired_accounts) {
        index++;
        var accountA = paired_accounts[key][0];
        var accountB = paired_accounts[key][1];

        if ((accountA.broker == broker && accountA.account_number == account_number)
            || (accountB.broker == broker && accountB.account_number == account_number)) {
            cursorIndex = index;
            refreshPairedTable();

            alert(cursorIndex);//TESTING!!!

            break;
        }
    }
}

function showNextPaired() {
    cursorNext();
    refreshPairedTable();

    alert(cursorIndex);//TESTING!!!
}

function showPreviousPaired() {
    cursorPrev();
    refreshPairedTable();

    alert(cursorIndex);//TESTING!!!
}

function RefreshSync() {
    ipc.send('refresh-sync', true);
}

function refreshPairedTable() {
    pair = currentPair();
    var html = pairedAccountHTML(pair);
    if (html) {
        document.getElementById('center-content-main').innerHTML = html;
    }
}

function refreshActionList() {
    var html = accountListHTML();
    if (html) {
        document.getElementById('right-pane').innerHTML = html;
    }
}

function setAccount(account) {
    if (!account.broker || !account.account_number) {
        console.warn('broker or account number not unknown - did you mean account?');
        return false;
    }
    if (account.peer) {
        paired_accounts[account.pair_id] = [];
        paired_accounts[account.pair_id][account.column_index] = account;
        paired_accounts[account.pair_id][account.peer.column_index] = account.peer;
    } else {
        addUnpaired(account);
    }
    return true;
}

function addUnpaired(account) {
    if (!account.broker || !account.account_number) {
        console.warn('broker or account number not known - did you mean account?');
        return;
    }
    const objIndex = unpaired_accounts.findIndex(obj => obj.broker === account.broker && obj.account_number === account.account_number);
    if (objIndex == -1) {
        unpaired_accounts.push(account);
    } else {
        unpaired_accounts[objIndex] = account;
    }
}

function removeAccount(account) {

    delete paired_accounts[account.pair_id];
    addUnpaired(account);
    addUnpaired(account.peer);
    return true;
}

function pairedAccountHTML(pair) {

    if (!pair) {
        return;
    }

    var tables = '';
    var tbody = '';

    var accountA = pair[0];
    var accountB = pair[1];

    var table = `
            <div class="ui teal segment">
                <div class="ui right floated pagination menu">
                        
                        <a class="icon item ${cursorIndex == 0 ? 'disabled' : ''}" onclick="showPreviousPaired()">
                          <i class="left chevron icon"></i>
                        </a>
                        <div class="item">
                        <span>${cursorIndex + 1}</span><span style="padding-left:10px;padding-right:10px;">of</span><span>${Object.keys(paired_accounts).length}</span>
                        </div>
                        <a class="icon item ${cursorIndex == Object.keys(paired_accounts).length - 1 ? 'disabled' : ''}"  onclick="showNextPaired()">
                          <i class="right chevron icon"></i>
                        </a>
                </div>
                <table class="ui compact celled definition structured table">
                    <thead class="full-width">
                      <tr>
                        <th colspan="2"></th>
                        <th  id="${tableColumnAID(accountA)}">

                                <h4 class="ui image header">
                                    <img src="${accountA.icon_file}">
                                    <div class="content">
                                        ${accountA.broker}
                                        <div class="sub header">
                                            ${accountA.account_number}
                                        </div>
                                    </div>
                                </h4>

                        </th>

                        <th id="${tableColumnBID(accountB)}">

                                <h4 class="ui image header">
                                    <img src="${accountB.icon_file}">
                                    <div class="content">
                                        ${accountB.broker}
                                        <div class="sub header">
                                            ${accountB.account_number}
                                        </div>
                                    </div>
                                </h4>

                        </th>
                    </tr>
                    </thead>
                    <tbody id="${tableContentID(accountA)}">
                    ${tableContent(pair)}
                    </tbody>
                    <tfoot class="full-width">
                      <tr>
                        <th></th>
                        <th colspan="4">
                          <div class="ui right floated small primary labeled icon button" onclick="RefreshSync()">
                            <i class="sync icon"></i> Refresh Sync
                          </div>
                  
                        </th>
                      </tr>
                    </tfoot>
                 </table>
            </div>`;

    return table;
}

function tableContent(pair) {
    var ordersA = pair[0].orders;
    var ordersB = pair[1].orders;
    var tbody = '';
    var count = 0;
    for (var i in ordersA) {

        var order_a = ordersA[i];

        if (order_a.peer_ticket == -1) {
            continue;
        }

        var found = false;
        var order_b;
        for (var k in ordersB) {
            order_b = ordersB[k];
            if (order_a.peer_ticket == order_b.ticket) {
                found = true;
                break;
            }
        }
        if (!found) {
            continue;
        }

        count++;
        tbody += `<tr>
                    <td rowspan = "7"  align="center" valign="middle" >${count}</td>
                    <td class="definition">SYMBOL</td>
                    <td>${order_a.symbol ? order_a.symbol : '-'}</td>
                    <td>${order_b.symbol ? order_b.symbol : '-'}</td>
                  </tr>
                  <tr>
                    <td>POSITION</td>
                    <td>${order_a.position ? order_a.position : '-'}</td>
                    <td>${order_b.position ? order_b.position : '-'} </td>
                  </tr>
                  <tr>
                    <td>TICKET</td>
                    <td>${order_a.ticket ? order_a.ticket : '-'}</td>
                    <td>${order_b.ticket ? order_b.ticket : '-'} </td>
                  </tr>
                  <tr>
                    <td>TARGET</td>
                    <td>${order_a.target || order_a.target == 0 ? order_a.target : '-'}</td>
                    <td>${order_b.target || order_a.target == 0 ? order_b.target : '-'} </td>
                  </tr>
                  <tr>
                    <td>STOPLOSS</td>
                    <td>${order_a.stoploss || order_a.stoploss == 0 ? order_a.stoploss : '-'}</td>
                    <td>${order_b.stoploss || order_a.stoploss == 0 ? order_b.stoploss : '-'} </td>
                  </tr>
                  <tr>
                    <td>STATUS</td>
                    <td>${getStatus(order_a)}</td>
                    <td>${getStatus(order_b)}</td>
                  </tr>
                  <tr>
                    <td>PROCESS</td>
                    <td>${getProcessIndication(order_a, order_b, 0)}</td>
                    <td>${getProcessIndication(order_a, order_b, 1)}</td>
                  </tr>`;

    }

    return tbody;
}

function getStatus(order) {
    if (order.open_time > 0 && order.close_time == 0)
        return 'OPEN';
    if (order.open_time > 0 && order.close_time > 0)
        return 'CLOSED';
    return 'UNKNOWN';
}

function SyncMessage(sub_msg) {
    return `<div class="ui icon mini message">
                  <i class="sync loading icon"></i>
                  <div class="content">
                    <div class="header">
                      Syncing...
                    </div>
                    <p>${sub_msg}.</p>
                  </div>
                </div>`;
}


function getProcessIndication(order_a, order_b, column_index) {


    //--Sending copy trade indicator
    var SendingCopyHtml = SyncMessage('Sending copy...');
    var ReceivingCopyHtml = SyncMessage('Receiving copy...');

    if (order_a.is_sync_copying && column_index == 0) {

        console.log(SendingCopyHtml);

        return SendingCopyHtml;
    }

    if (order_a.is_sync_copying && column_index == 1) {

        console.log(ReceivingCopyHtml);

        return ReceivingCopyHtml;
    }

    if (order_b.is_sync_copying && column_index == 1) {

        console.log(SendingCopyHtml);

        return SendingCopyHtml;
    }

    if (order_b.is_sync_copying && column_index == 0) {

        console.log(ReceivingCopyHtml);

        return ReceivingCopyHtml;
    }


    //--Sending close trade indicator

    var SendingCloseHtml = SyncMessage('Sending close...');
    var ReceivingCloseHtml = SyncMessage('Receiving close...');

    if (order_a.is_sync_closing && column_index == 0) {

        console.log(SendingCloseHtml);

        return SendingCloseHtml;
    }

    if (order_a.is_sync_closing && column_index == 1) {

        console.log(ReceivingCloseHtml);

        return ReceivingCloseHtml;
    }

    if (order_b.is_sync_closing && column_index == 1) {

        console.log(SendingCloseHtml);

        return SendingCloseHtml;
    }

    if (order_b.is_sync_closing && column_index == 0) {

        console.log(ReceivingCloseHtml);

        return ReceivingCloseHtml;
    }

    //--Sending modify target indicator
    var SendingModifyTargetHtml = SyncMessage('Sending modify target...');
    var ReceivingModifyTargetHtml = SyncMessage('Receiving modify target...');


    if (order_a.is_sync_modifying_target && column_index == 0) {

        console.log(SendingModifyTargetHtml);

        return SendingModifyTargetHtml;
    }

    if (order_a.is_sync_modifying_target && column_index == 1) {

        console.log(ReceivingModifyTargetHtml);

        return ReceivingModifyTargetHtml;
    }

    if (order_b.is_sync_modifying_target && column_index == 1) {

        console.log(SendingModifyTargetHtml);

        return SendingModifyTargetHtml;
    }

    if (order_b.is_sync_modifying_target && column_index == 0) {

        console.log(ReceivingModifyTargetHtml);

        return ReceivingModifyTargetHtml;
    }

    //--Sending modify stoploss indicator
    var SendingModifyStoplossHtml = SyncMessage('Sending modify stoploss...');
    var ReceivingModifyStoplossHtml = SyncMessage('Receiving modify stoploss...');


    if (order_a.is_sync_modifying_stoploss && column_index == 0) {

        console.log(SendingModifyStoplossHtml);

        return SendingModifyStoplossHtml;
    }

    if (order_a.is_sync_modifying_stoploss && column_index == 1) {

        console.log(ReceivingModifyStoplossHtml);

        return ReceivingModifyStoplossHtml;
    }

    if (order_b.is_sync_modifying_stoploss && column_index == 1) {

        console.log(SendingModifyStoplossHtml);

        return SendingModifyStoplossHtml;
    }

    if (order_b.is_sync_modifying_stoploss && column_index == 0) {

        console.log(ReceivingModifyStoplossHtml);

        return ReceivingModifyStoplossHtml;
    }



    if (!order_a.symbol && column_index == 0) {
        return '-';
    }

    if (!order_b.symbol && column_index == 1) {
        return '-';
    }

    return '<i class="large green checkmark icon"></i>';//Tick mark
}

function accountListHTML() {
    var html = '';
    for (var n in paired_accounts) {
        var pair = paired_accounts[n];
        html += accountItemHTML(pair[0]);
        html += accountItemHTML(pair[1]);
    }

    for (var i in unpaired_accounts) {
        html += accountItemHTML(unpaired_accounts[i]);
    }

    return `<div class="ui celled selection list">${html}</div>`;
}

function accountItemHTML(account) {
    return `<div class="item"  onclick="showPaired('${account.broker}','${account.account_number}')">
                    <img class="ui avatar image" src="${account.icon_file}">
                    <div class="content">
                        <a class="header">${account.broker}</a>
                        <div class="description">${account.account_number}</div>
                    </div>
                </div>`;
}

function tableContentID(account) {
    return `table-${getPairID(account)}`;
}

function tableColumnAID(account) {
    return `table-col-a-${getPairID(account)}`;
}

function tableColumnBID(account) {
    return `table-col-b-${getPairID(account)}`;
}

function getPairID(account) {
    var id = account.broker + "-" + account.account_number;
    var id = id.replace(new RegExp(' ', 'g'), '-');
    return id;
}
