
export class SyncTraderException extends Error {
    constructor(message: string) {
        super(message);
    }
}