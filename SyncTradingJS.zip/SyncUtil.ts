
import { App, fs, path, mkdirp } from "./app";
import { Order } from "./Order";
import { Config } from "./Config";
import { Constants } from "./Constants";
import { TraderAccount } from "./TraderAccount";


export class SyncUtil {
  
    static SymbolGroups: Array<Array<string>> = new Array<Array<string>>();
    static TerminalIconMap: Map<string, string> = new Map<string, string>();

    static ArrayRemove(arr: Array<unknown>, element: unknown) {
        const objIndex = arr.findIndex(obj => obj === element);
        if (objIndex > -1) {
            arr.splice(objIndex, 1);
        }
    }

    static replaceAll(name: string, search: string, replacement: string): string {

        while (true) {
            var d_name = name;

            d_name = d_name.replace(search, replacement);

            if (d_name == name) {
                break;
            }
            name = d_name;
        }

        return name;

    }

    static SetSymbolGroups(symb_grps: string): void {
        //SymbolGroups

        symb_grps = this.replaceAll(symb_grps.trim(), '\r\n', '\n')//replace all '\r\n' with single new line
        symb_grps = this.replaceAll(symb_grps.trim(), '\n\n', '\n')//remove excess '\n' delimeter
        symb_grps = this.replaceAll(symb_grps.trim(), ';;', ';')//remove excess ';' delimeter	

        var groups = []

        var arr = symb_grps.split('\n');
        for (var i = 0; i < arr.length; i++) {
            var larr = arr[i].split(';');
            var lgrp_arr = [];
            for (var k = 0; k < larr.length; k++) {
                larr[k] = larr[k].trim();
                if (larr[k] != '') {
                    lgrp_arr.push(larr[k]);
                }
            }

            if (lgrp_arr.length > 0) {
                groups.push(lgrp_arr);
            }
        }

        if (groups.length > 0) {
            SyncUtil.SymbolGroups = groups
        }

    }

    static ExtenalBrokersSymbols(): void {

        var file = Config.BROKER_SYMBOL_GROUPS_FILE;
        var dirname = path.dirname(file);
        if (!fs.existsSync(dirname)) {
            mkdirp.sync(dirname);
        }
        var fd = fs.openSync(file, 'a+');//open for reading and appending

        var stats = fs.statSync(file);
        var size = stats['size'];
        var buffer = Buffer.alloc(size);

        if (size === 0) {
            return; //nothing to do
        }

        fs.readSync(fd, buffer, 0, size, null);

        var data = buffer.toString(); //toString(0, length) did not work but toString() worked for me

        this.SetSymbolGroups(data);
        var that = this;
        fs.watchFile(file, { interval: 3000 }, (curr, prev) => {

            fs.readFile(file, (err, data) => {
                if (err) {
                    console.log(err);
                    return;
                }
                that.SetSymbolGroups(data.toString());
            });

        });

    }

    static GetSymbolGroup(symbol: string): string {

        var seperator = ';';
        var groups = SyncUtil.SymbolGroups;
        var symb_grp = '';
        for (var i = 0; i < groups.length; i++) {
            if (groups[i].indexOf(symbol) == -1) {
                continue;
            }
            var glen = groups[i].length;

            for (var k = 0; k < glen; k++) {

                var sep = k < glen - 1 ? seperator : '';

                symb_grp += groups[i][k] + sep;
            }

            break;
        }

        return symb_grp;
    }

    public static SyncCopyPacket(order: Order, trade_copy_type: string): string {
        return `ticket=` + order.ticket + Constants.TAB
            + `position=` + order.position + Constants.TAB
            + `target=` + order.stoploss + Constants.TAB//yes, target becomes the stoploss of the sender - according to the strategy
            + `stoploss=` + order.target + Constants.TAB//yes, stoploss becomes the target of the sender - according to the strategy
            + `symbol=` + order.symbol + Constants.TAB
            + `raw_symbol=` + order.raw_symbol + Constants.TAB
            + `symbol_group=` + SyncUtil.GetSymbolGroup(order.raw_symbol) + Constants.TAB
            + `lot_size=` + order.lot_size + Constants.TAB +
            `trade_copy_type=` + trade_copy_type + Constants.TAB + `action=sync_copy`;
    }

    public static SyncClosePacket(ticket: number, origin_ticket: number): string {
        return `ticket=` + ticket + Constants.TAB // the ticket to be closed
            + `origin_ticket=` + origin_ticket + Constants.TAB + `action=sync_close`;
    }

    public static SyncModifyTargetPacket(price: number, ticket: number, origin_ticket: number): string {
        return `target=` + price + Constants.TAB
            + `ticket=` + ticket + Constants.TAB
            + `origin_ticket=` + origin_ticket + Constants.TAB
            + `action=sync_modify_target`;
    }

    public static SyncModifyStoplossPacket(price: number, ticket: number, origin_ticket: number): string {
        return `stoploss=` + price + Constants.TAB
            + `ticket=` + ticket + Constants.TAB
            + `origin_ticket=` + origin_ticket + Constants.TAB
            + `action=sync_modify_stoploss`;
    }
    public static Intro(): string {
        return "action=intro"
    }
    public static PingPacket(): string {
        return "ping=pong"
    }

    public static NormalizeName(name: string): string {

        name = name.trim();

        var single_space = " ";
        var double_space = single_space + single_space;

        while (true) {
            var d_name = name;

            d_name = d_name.replace(double_space, single_space);
            d_name = d_name.replace(",", "");
            d_name = d_name.replace(".", "");

            if (d_name == name) {
                break;
            }
            name = d_name;
        }

        return name;
    }

    static LogCopyRetry(account: TraderAccount, origin_ticket: number, attempts: number) {
        var final: string = attempts >= Constants.MAX_COPY_RETRY ? "FINAL " : "";
        console.log(`[${attempts}] ${final}COYP RETRY : Sending copy #${origin_ticket} from [${account.Broker()}, ${account.AccountNumber()}] to [${account.Peer().Broker()}, ${account.Peer().AccountNumber()}]`);
    }

    static LogCloseRetry(account: TraderAccount, origin_ticket: number, peer_ticket: number, attempts: number) {
        var final: string = attempts >= Constants.MAX_CLOSE_RETRY ? "FINAL " : "";
        console.log(`[${attempts}] ${final}CLOSE RETRY : Sending close of #${origin_ticket} to target #${peer_ticket} - from [${account.Broker()}, ${account.AccountNumber()}] to [${account.Peer().Broker()}, ${account.Peer().AccountNumber()}]`);
    }

    static LogModifyTargetRetry(account: TraderAccount, origin_ticket: number, peer_ticket: number, attempts: number) {
        var final: string = attempts >= Constants.MAX_MODIFY_RETRY ? "FINAL " : "";
        console.log(`[${attempts}] ${final}MODIFY TARGET RETRY : Sending changed stoploss(${origin_ticket})  of #${origin_ticket} to modify target price of #${peer_ticket} - from [${account.Broker()}, ${account.AccountNumber()}] to [${account.Peer().Broker()}, ${account.Peer().AccountNumber()}]`);
    }

    static LogModifyStoplossRetry(account: TraderAccount, origin_ticket: number, peer_ticket: number, attempts: number) {
        var final: string = attempts >= Constants.MAX_MODIFY_RETRY ? "FINAL " : "";
        console.log(`[${attempts}] ${final}MODIFY STOPLOSS RETRY : Sending changed target(${origin_ticket})  of #${origin_ticket} to modify stoploss price of #${peer_ticket} - from [${account.Broker()}, ${account.AccountNumber()}] to [${account.Peer().Broker()}, ${account.Peer().AccountNumber()}]`);
    }
    
    static BrokerIconFiles(): void {

        try {

            //first load the sync state of the trades
            var file = Config.SYNC_ICON_FILE;
            var dirname = path.dirname(file);
            if (!fs.existsSync(dirname)) {
                mkdirp.sync(dirname);
            }

            var fd = null;
            if (fs.existsSync(file)) {//file exists

                //according to doc - Open file for reading and writing.
                //An exception occurs if the file does not exist
                //So since we know that at this point the file exists we are not bothered about exception 
                //since it will definitely not be thrown

                fd = fs.openSync(file, 'r+');
            } else {//file does not exist

                //according to doc - Open file for reading and writing.
                //The file is created(if it does not exist) or truncated(if it exists).
                //So since we known that at this point it does not we are not bothered about the truncation

                fd = fs.openSync(file, 'w+');
            }


            var stats = fs.statSync(file);
            var size = stats['size'];
            var rq_size = size;
            var readPos = size > rq_size ? size - rq_size : 0;
            var length = size - readPos;
            var buffer = Buffer.alloc(length);

            if (length > 0) {

                fs.readSync(fd, buffer, 0, length, readPos);

                var data = buffer.toString(); //toString(0, length) did not work but toString() worked for me

                this.TerminalIconMap = new Map(JSON.parse(data));
            }

        } catch (e) {
            console.log(e);
            throw e;
        }

    }

    static GetTerminalIcon(normalize_broker: string): string {

        var iconfile = this.TerminalIconMap.get(normalize_broker);
        if (iconfile) {
            return iconfile;
        }

        var dir = Config.PROPGRAM_FOLDER32;
        var files = fs.readdirSync(dir);
        for (var i in files) {
            var file = files[i];
            var name = dir + '/' + file;
            if (!fs.statSync(name).isDirectory()) {
               continue
            }
            //at this point it is a directory
            var brksplit = normalize_broker.split(' ');
            var partfile = '';
            var part_arr = [];
            for (var n in brksplit) {
                partfile += brksplit[n];
                part_arr.push(partfile);
                partfile += " ";
            }

            //check from the full to truncated name
            for (var k = part_arr.length - 1; k > -1; k--) {
                var ptfile = part_arr[k];
                if (file.startsWith(ptfile)) {
                    var pathname = name + '/' + 'terminal.ico';
                    if (!fs.existsSync(pathname)) {
                        continue;
                    }
                    this.TerminalIconMap.set(normalize_broker, pathname);
                    var data = JSON.stringify(Array.from(this.TerminalIconMap.entries()));

                    //overwrite the file content
                    fs.writeFile(Config.SYNC_ICON_FILE, data, { encoding: 'utf8', flag: 'w' }, function (err) {
                        if (err) {
                            return console.log(err);
                        }
                    })

                    return pathname;

                }
            }

        }

        return ''
    }

}