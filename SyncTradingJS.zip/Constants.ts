
export class Constants {
    
    public static readonly TAB: string = "\t";
    public static readonly NEW_LINE: string = "\n";
    public static readonly MAX_COPY_RETRY: number = 3;
    public static readonly MAX_CLOSE_RETRY: number = 3;
    public static readonly MAX_MODIFY_RETRY: number = 3;
    public static trade_condition_not_changed: string = "no error, trade conditions not changed";
}
