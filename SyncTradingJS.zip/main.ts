'use strict';

  Object.defineProperty(exports, "__esModule", { value: true });

import { App } from './app';
//const App = require('./app').App
const { app, ipcMain, BrowserWindow } = require('electron')

var win;

var mainApp = new App();

export var ipcSend = function (event, data) {   
    win.webContents.send(event, data);//UNCOMMETN LATER
}

//new App().Run();//TO BE REMOVED AFTER TESTING!!!


function createWindow() {

    win = new BrowserWindow({
        width: 1300,
        height: 750,
        webPreferences: {
            nodeIntegration: true
        }
    })

    // and load the index.html of the app. 
    win.loadFile('../index.html')

    // Open the DevTools. 
    win.webContents.openDevTools()

    //Quit app when main BrowserWindow Instance is closed
    win.on('closed', function () {
        app.quit();
    });
}

// This method will be called when the Electron has finished 
// initialization and is ready to create browser windows. 
// Some APIs can only be used after this event occurs. 
app.whenReady().then(createWindow)

app.on('window-all-closed', () => {
    // On macOS it is common for applications and their menu bar    
    // to stay active until the user quits explicitly with Cmd + Q 
    if (process.platform !== 'darwin') {
        app.quit()
    }
})

app.on('activate', () => {
    // On macOS it's common to re-create a window in the app when the 
    // dock icon is clicked and there are no other windows open. 
    if (BrowserWindow.getAllWindows().length === 0) {
        createWindow()
    }
})


ipcMain.on('start-sync', function (event, arg) {
    mainApp.Run();
});

ipcMain.on('refresh-sync', function (event, arg) {
    mainApp.GetSyncService().RevalidateSyncAll();
});