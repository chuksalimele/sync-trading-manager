
export class Config {
    static readonly WORKING_DIRECTORY: string = process.cwd();
    public static readonly PIPE_PATH: string = "\\\\.\\pipe\\sync_trades_pipe";
    public static readonly SYNC_LOG_FILE: string = Config.WORKING_DIRECTORY + "/log/sync_log.sync";
    public static readonly SYNC_ICON_FILE: string = Config.WORKING_DIRECTORY + "/ext/terminal_icons.sync";
   
    public static readonly BROKER_SYMBOL_GROUPS_FILE: string = Config.WORKING_DIRECTORY + "/symbols.txt";
    public static readonly PROPGRAM_FOLDER64 = 'C:/Program Files';
    public static readonly PROPGRAM_FOLDER32 = 'C:/Program Files (x86)';

}
